package com.vikas.news;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class NewsServiceTest {

    @Test
    void simpleTest() {
        assertEquals(5, 2 + 3);
    }
}
