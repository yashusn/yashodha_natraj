package com.example.service;

import org.springframework.stereotype.Service;

@Service
public class ParcelService {
    // Add service methods as needed
}

