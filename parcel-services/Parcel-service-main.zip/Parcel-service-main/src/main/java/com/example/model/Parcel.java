package com.example.model;

public class Parcel {
    // Add fields as needed
}

